# Polish Web Service

HTTP service for Polish stress analysis powered by the Rust WASM engine.

## Run locally

From repository root:

1. Install dependencies
   pnpm install

2. Start service
   pnpm run dev:web-service

Service defaults:
- HOST=0.0.0.0
- PORT=8787

## Endpoints

- GET /health
- GET /stress?word=matematyka
- POST /stress with JSON body: { "word": "matematyka" }
- GET /stress/index?word=matematyka
